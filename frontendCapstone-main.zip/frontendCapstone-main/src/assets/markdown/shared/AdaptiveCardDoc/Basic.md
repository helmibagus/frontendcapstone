```jsx
import AdaptableCard from '@/components/shared/AdaptableCard'

const Basic = () => {
    return <AdaptableCard>Card content</AdaptableCard>
}

export default Basic
```
