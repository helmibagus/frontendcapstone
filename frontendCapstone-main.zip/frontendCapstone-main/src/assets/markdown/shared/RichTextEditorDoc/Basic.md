```jsx
import RichTextEditor from '@/components/shared/RichTextEditor'

const Basic = () => {
    return <RichTextEditor content="Hello World" />
}

export default Basic
```
