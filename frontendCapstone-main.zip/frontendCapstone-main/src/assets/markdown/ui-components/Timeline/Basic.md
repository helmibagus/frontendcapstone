```jsx
import Timeline from '@/components/ui/Timeline'

const Basic = () => {
    return (
        <div>
            <Timeline>
                <Timeline.Item>Breakfast - 09:00</Timeline.Item>
                <Timeline.Item>Lunch - 12:30</Timeline.Item>
                <Timeline.Item>Dinner - 7:00</Timeline.Item>
            </Timeline>
        </div>
    )
}

export default Basic
```
