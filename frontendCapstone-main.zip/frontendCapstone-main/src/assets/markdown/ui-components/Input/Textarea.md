```jsx
import Input from '@/components/ui/Input'

const Textarea = () => {
    return (
        <div>
            <Input placeholder="Text area example" textArea />
        </div>
    )
}

export default Textarea
```
