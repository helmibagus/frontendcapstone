```jsx
import DatePicker from '@/components/ui/DatePicker'

const Basic = () => {
    return <DatePicker placeholder="Pick a date" />
}

export default Basic
```
