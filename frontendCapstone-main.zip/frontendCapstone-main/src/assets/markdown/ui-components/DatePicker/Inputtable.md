```jsx
import DatePicker from '@/components/ui/DatePicker'

const Inputtable = () => {
    return (
        <DatePicker
            inputtable
            inputtableBlurClose={false}
            placeholder="Pick date"
        />
    )
}

export default Inputtable
```
