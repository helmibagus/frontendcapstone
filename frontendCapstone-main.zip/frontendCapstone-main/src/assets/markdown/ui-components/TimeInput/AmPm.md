```jsx
import TimeInput from '@/components/ui/TimeInput'

const AmPm = () => {
    return <TimeInput format="12" defaultValue={new Date()} />
}

export default AmPm
```
