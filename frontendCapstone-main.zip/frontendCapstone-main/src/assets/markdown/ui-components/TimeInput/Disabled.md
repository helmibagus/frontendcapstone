```jsx
import TimeInput from '@/components/ui/TimeInput'

const Disabled = () => {
    return (
        <div className="flex flex-col gap-5">
            <TimeInput disabled />
        </div>
    )
}

export default Disabled
```
