```jsx
import Card from '@/components/ui/Card'

const BorderLess = () => {
    return (
        <div>
            <Card bordered={false}>
                <h5>Card title</h5>
                <p>
                    Some quick example text to build on the card title and make
                    up the bulk of the card&apos;s content.
                </p>
            </Card>
        </div>
    )
}

export default BorderLess
```
