```jsx
import Pagination from '@/components/ui/Pagination'

const Total = () => {
    return (
        <div>
            <Pagination displayTotal total={50} />
        </div>
    )
}

export default Total
```
