```jsx
import Progress from '@/components/ui/Progress'

const ProgressBar = () => {
    return (
        <div>
            <Progress percent={30} />
        </div>
    )
}

export default ProgressBar
```
