import DemoCard from './DemoCard'

export default DemoCard
