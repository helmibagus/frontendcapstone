import RichTextEditor from './RichTextEditor'

export type { RichTextEditorRef } from './RichTextEditor'

export default RichTextEditor
